package com.example.demo.parameter;

public class DatabaseParameter {

    public static final String DB_NAME_MOREMORE = "moremore";
    public static final String DB_TABLE_USERS = "users";
    public static final String DB_TABLE_USERS_USERNAME = "username";


}
