package com.example.demo.repository;

import com.example.demo.model.SiteUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<SiteUser, String> {

    SiteUser findByUsername(String username);
    String findRoleByRole(String role);
}
