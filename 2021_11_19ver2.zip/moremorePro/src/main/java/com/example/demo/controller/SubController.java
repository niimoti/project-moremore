package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SubController {

    //このクラス消していいよ
    @GetMapping("/sampleA")
    public String a(Model model) {
        model.addAttribute("username","aaa");
        model.addAttribute("role","iii");
        return "/student/menu";
    }

}
