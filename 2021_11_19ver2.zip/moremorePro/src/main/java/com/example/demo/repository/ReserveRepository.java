package com.example.demo.repository;

import com.example.demo.model.MultiplePrimary;
import com.example.demo.model.Reserve;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReserveRepository extends JpaRepository<Reserve, MultiplePrimary.ReservePrimary> {
    List<Reserve> findByUsername(String username);
}
