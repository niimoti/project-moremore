package com.example.demo.controller;

import com.example.demo.java.Time;
import com.example.demo.model.Reserve;
import com.example.demo.repository.ExplanationRepository;
import com.example.demo.repository.ReserveRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class StudentController {

    //学生Controller
    private final ExplanationRepository explanationRepository;
    private final UserRepository userRepository;
    private final ReserveRepository reserveRepository;

    @Autowired
    public StudentController(
            ExplanationRepository explanationRepository,
            UserRepository userRepository,
            ReserveRepository reserveRepository) {
        this.explanationRepository = explanationRepository;
        this.userRepository = userRepository;
        this.reserveRepository = reserveRepository;
    }


    @GetMapping("")
    public String studentMenu() {
        return "";
    }

    //ここを自身のアカウントを検索するようにしなければならない
    //また遷移先のhtmlもかえろ
    @GetMapping("/student/ReserveSample")
    public String ReserveSample2(
            Model model
    ) {
        model.addAttribute("list",explanationRepository.findAll());
        return "student/ReserveSample";
    }

    @PostMapping("/student/Reservation")
    public String Reservation(
            Model model,
            @RequestParam String comname,
            Authentication loginUser
    ) {
        Reserve reserve = new Reserve();
        Time time = new Time();
        String timeStr = time.NowTime();
        System.out.println(timeStr);
        reserve.setCompanyname(comname);
        String stuname = loginUser.getName();
        reserve.setUsername(stuname);
        reserve.setDatetime(timeStr);

        System.out.println(reserve.getCompanyname() +
                reserve.getUsername() +
                reserve.getDatetime());

        reserveRepository.save(reserve);
        model.addAttribute("comname",comname);
        model.addAttribute("stuname",stuname);
        return "student/ReserveConfirm";
    }

    @GetMapping("/student/Reservationlist")
    public String Reservationlist2(
            Model model,
            Authentication loginUser
    ) {
        String stuname = loginUser.getName();
        model.addAttribute("users", userRepository.findByUsername(stuname));
        model.addAttribute("reservation",reserveRepository.findByUsername(stuname));
        model.addAttribute("stu", stuname);
        return "student/Reservationlist";
    }
}
