package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "schedule")
@NoArgsConstructor
@AllArgsConstructor
public class Schedule {

    @Id
    @GeneratedValue
    @Column(name = "id")
    private String id;

    //ユーザID
    @Column(name = "user_id")
    private String userId;

    //予定日
    @Column(name = "scheduled_date")
    private int scheduledDate;

    //企業ID
    @Column(name = "enterprise_id")
    private String EnterpriseId;

}
