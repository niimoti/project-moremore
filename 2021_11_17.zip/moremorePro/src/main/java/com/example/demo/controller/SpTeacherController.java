package com.example.demo.controller;

import com.example.demo.java.*;
import com.example.demo.model.Companys;
import com.example.demo.model.InformationSessionModel;
import com.example.demo.model.SiteUser;
import com.example.demo.repository.*;
import net.bytebuddy.utility.RandomString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
public class SpTeacherController {

    //-----------session start---------
    final
    HttpSession session;

    //-----------repository and session------------

    private final InformationSessionRepository informationSessionRepository;
    private final BriefingSessionRepository briefingSessionRepository;
    private final CompanysRepository companysRepository;
    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final ReserveRepository reserveRepository;
    private final QualificationRepository qualificationRepository;

    @Autowired
    public SpTeacherController(InformationSessionRepository informationSessionRepository, BriefingSessionRepository briefingSessionRepository, HttpSession session, CompanysRepository companysRepository, UserRepository userRepository, StudentRepository studentRepository, ReserveRepository reserveRepository, QualificationRepository qualificationRepository) {
        this.informationSessionRepository = informationSessionRepository;
        this.briefingSessionRepository = briefingSessionRepository;
        this.session = session;
        this.companysRepository = companysRepository;
        this.userRepository = userRepository;
        this.studentRepository = studentRepository;
        this.reserveRepository = reserveRepository;
        this.qualificationRepository = qualificationRepository;
    }

    //---------- fileSave--------------
    private String getExtension(String filename) {
        int dot = filename.lastIndexOf(".");
        if (dot > 0) {
            return filename.substring(dot).toLowerCase();
        }
        return "";
    }

    private String getUploadFileName(String fileName) {

        File file = new File(fileName);
        String basename = file.getName();
        String woext = basename.substring(0, basename.lastIndexOf('.'));

        return woext + "_" +
                DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS")
                        .format(LocalDateTime.now())
                + getExtension(fileName);
    }

    private void createDirectory() {
        Path path = Paths.get("PDF");
        if (!Files.exists(path)) {
            try {
                Files.createDirectory(path);
            } catch (Exception e) {
                //エラー処理は省略
            }
        }
    }

    private String savefile(MultipartFile file) {
        String filename = getUploadFileName(file.getOriginalFilename());
        Path uploadfile = Paths.get("PDF/" + filename);
        try (var os = Files.newOutputStream(uploadfile, StandardOpenOption.CREATE)) {
            byte[] bytes = file.getBytes();
            os.write(bytes);

            return filename;
        } catch (IOException e) {
            //エラー処理は省略
            return "";
        }
    }

    private String savefiles(List<MultipartFile> multipartFiles) {
        createDirectory();
        String fileName = "";
        for (MultipartFile file : multipartFiles) {
            fileName = savefile(file);
        }
        return fileName;
    }

    //---------------------------------就職講師Controller

    //---------------------------------説明会

    @GetMapping("/spteacher/disposeOfPDF")
    public String disposeOfPDF() {
        DeleteFile deleteFile = new DeleteFile();
        deleteFile.OnAllDelete();
        return "spteacher/menu";
    }


    //ログイン実装はあとあとがだるいのでログインした体での実装
    @RequestMapping("/spteacher/spC")
    public String sp() {
        return "spteacher/menu";
    }

    //入力画面に飛ぶよ
    @GetMapping("/spteacher/addInformationSession")
    public String addIS() {
        return "spteacher/addInformationSession";
    }


    //入力画面からの入力を受付けて、modelにデータを渡すよ
    @PostMapping("/spteacher/ISok")
    public String isok(
            AddEnterpriseData addData
    ) {

        if (addData.getTempfile() == null || addData.getTempfile().isEmpty()) {
            //エラー時の処理
            //まあファイルがなかった時の処理だね(´・ω・`)
            return "spteacher/menu";
        }
        assert addData.getTempfile() != null;
        String fileName = savefiles(addData.getTempfile());

        InformationSessionModel spModel = new InformationSessionModel();
        spModel.setKName(addData.getKName());
        spModel.setIndustry(addData.getIndustry());
        spModel.setDay(addData.getDay());
        spModel.setContents(addData.getContents());
        spModel.setPlace(addData.getPlace());
        spModel.setDeadline(addData.getDeadline());
        spModel.setURL(addData.getURL());
        spModel.setExplanation(addData.getExplanation());
        spModel.setTempfile(fileName);
        //(!companysRepository.findById(addData.getKName()).isPresent())
        if (companysRepository.findById(addData.getKName()).isEmpty()) {
            //なかった場合はtable Companysに企業名を主キーに、業種を追加
            Companys companys = new Companys();
            companys.setCompanysname(addData.getKName());
            companys.setIndustry(addData.getIndustry());
            companysRepository.save(companys);
        } else {
            //あった場合の処理
        }

        informationSessionRepository.save(spModel);

        return "redirect:/spteacher/spC";
    }

    @GetMapping("/spteacher/ISok")
    public String isokGet() {
        System.out.println("Getで受け取ったよ");
        return "spteacher/menu";
    }

    @PostMapping("/spteacher/ISChangeOkey")
    public String ISChange(
            @RequestParam String day,
            @RequestParam String place,
            @RequestParam String deadline,
            @ModelAttribute InformationSessionModel informationSessionModel,
            Model model
    ) {

        try {
            String id = session.getAttribute("isId").toString();
            if (id.equals("")) {
                model.addAttribute("ketsu", informationSessionRepository.findAll());
            } else {
                InformationSessionModel informationSessionModel1;
                InformationSessionModel informationSessionModel2;
                ExString exString = new ExString();
                UpdateAssistance updateAssistance = new UpdateAssistance();

                informationSessionModel2 = informationSessionRepository.findAllById(exString.getLong(id));

                informationSessionModel1 = updateAssistance.updateISM(
                        id,day,place,deadline,
                        informationSessionModel2.getKName(),
                        informationSessionModel2.getIndustry(),
                        informationSessionModel2.getContents(),
                        informationSessionModel2.getURL(),
                        informationSessionModel2.getExplanation(),
                        informationSessionModel2.getTempfile()
                );

                informationSessionRepository.save(informationSessionModel1);
//        informationSessionRepository.customUpdateFileById(day, deadline, place, id);
                model.addAttribute("ketsu", informationSessionRepository.findAll());
                session.setAttribute("isId","");
            }
            return "redirect:/spteacher/ISSearch";
        } catch (Exception e) {
            model.addAttribute("ketsu", informationSessionRepository.findAll());
            return "redirect:/spteacher/ISSearch";
        }


    }

    @GetMapping("/spteacher/ISSearch")
    public String ketsuANA(
            @ModelAttribute InformationSessionModel informationSessionModel,
            Model model
    ) {
        model.addAttribute("ketsu", informationSessionRepository.findAll());
        return "spteacher/ISSearch";
    }
    @GetMapping("/spteacher/ISSearchByCompany")
    public String CompanySearch(
            Model model,
            @RequestParam String kName
    ) {
        try {
            model.addAttribute("ketsu",informationSessionRepository.findBykNameContaining(kName));
        } catch (Exception e) {
            model.addAttribute("ketsu",informationSessionRepository.findAll());
        }
        model.addAttribute("ketsu",informationSessionRepository.findBykNameContaining(kName));
        return "spteacher/ISSearch";
    }

    @PostMapping("/spteacher/ISprint")
    public String ISChange(
            Model model,
            @RequestParam String isId,
            @ModelAttribute InformationSessionModel informationSessionModel
    ) {
        ExString exString = new ExString();
        model.addAttribute("filePath2",informationSessionRepository.findAllById(exString.getLong(isId)));
        return "spteacher/ISprint";
    }

    @PostMapping("/spteacher/ISChange")
    public String ISChange(
            @RequestParam String isId,
            Model model
    ) {
        System.out.println(isId);
        ExString exString = new ExString();


//        model.addAttribute("changeData", informationSessionRepository.customFindChangesById(isId));
        model.addAttribute("changeData", informationSessionRepository.findAllById(exString.getLong(isId)));
        session.setAttribute("isId", isId);
        return "spteacher/ISChange";
    }

    @PostMapping("/spteacher/ISDelete")
    public String ISDelete(
            @RequestParam String isId,
            Model model
    ) {
        ExString exString = new ExString();
//        String filePath = informationSessionRepository.customFindFilePathById(isId);
        InformationSessionModel informationSessionModel;
        informationSessionModel = informationSessionRepository.findAllById(exString.getLong(isId));

        System.out.println(informationSessionModel.getTempfile());
        DeleteFile deleteFile = new DeleteFile();
        deleteFile.OnDelete(informationSessionModel.getTempfile());
//        informationSessionRepository.customDeleteFileById(exString.getLong(isId));
        informationSessionRepository.deleteById(exString.getLong(isId));


        model.addAttribute("ketsu", informationSessionRepository.findAll());
        return "redirect:/spteacher/ISSearch";
    }

    //------------------------------企業

    //企業追加
    @GetMapping("/spteacher/addCompanys")
    public String addCompanys() {
        return "spteacher/addCompanys";
    }

    @PostMapping("/spteacher/addCompanysOkey")
    public String addCompanysOkey(
            @RequestParam String companysname,
            @RequestParam String industry
    ) {
        Companys companys = new Companys();
        companys.setCompanysname(companysname);
        companys.setIndustry(industry);

        if (companysRepository.findById(companysname).isPresent()) {
            System.out.println("主キーが重複したため登録を拒否しました");
            return "redirect:/spteacher/spC";
        }
        companysRepository.save(companys);
        return "redirect:/spteacher/spC";
    }

    //企業検索
    @GetMapping("/spteacher/searchCompanys")
    public String searchCompanys(
            Model model,
            @ModelAttribute Companys companys
    ){
        model.addAttribute("Companys",companysRepository.findAll());
        return "/spteacher/searchCompanys";
    }
    //企業検索
    @GetMapping("/spteacher/searchCompanysByLike")
    public String searchCompanysByLike(
            Model model,
            @ModelAttribute Companys companys,
            @RequestParam String company
    ){
        model.addAttribute("Companys",companysRepository.findByCompanysnameContaining(company));
        return "/spteacher/searchCompanys";
    }

    @PostMapping("/spteacher/companysChange")
    public String changeCompanys(
            Model model,
            @RequestParam(name = "companysName") String companysName
    ){
//        Companys companys = companysRepository.
        System.out.println(companysName);
        //トークンの生成&セッションでサーバとクライアントで同じ値を所持させる
        String randomStr = RandomString.make(10);
        session.setAttribute("token",randomStr);
        model.addAttribute("token",randomStr);

        if (companysRepository.findById(companysName).isPresent()) {
            model.addAttribute("company", companysRepository.findById(companysName));
            model.addAttribute("company2", companysRepository.findAll());
            model.addAttribute("keyword", companysName);
            session.setAttribute("sessionCompanyName",companysName);
            return "spteacher/changeCompany";
        } else {
            System.out.println("企業名が存在しません");
            return "/spteacher/menu";
        }

    }

    @PostMapping("/spteacher/companysChangeOkey")
    public String companysChangeOkey(
            Model model,
            @RequestParam String industry,
            @RequestParam String token
    ) {
        System.out.println("更新準備");
        String tokenServer = session.getAttribute("token").toString();
        System.out.println("tokenC:" + token);
        System.out.println("tokenS:" + tokenServer);
        //セッション内のトークンとclientからわたってきたトークンを比較して同じなら
        // 処理を実行、違うなら検索画面に飛ばす
        if (token.equals(tokenServer)) {
            System.out.println(industry);
            String companysname = session.getAttribute("sessionCompanyName").toString();
            Companys companys = new Companys();
            companys.setCompanysname(companysname);
            companys.setIndustry(industry);
            companysRepository.save(companys);
            System.out.println("更新完了");
            session.setAttribute("token","");
//        model.addAttribute("Companys",companysRepository.findAll());
        } else {
            System.out.println("トークンが一致していません。");
        }
        return "redirect:/spteacher/searchCompanys";


    }

    //--------------学生管理画面-----------------

    //学生一覧表示
    @GetMapping("/spteacher/searchByStudent")
    public String searchByStudent(
            Model model
    ) {
        model.addAttribute("studentAll",studentRepository.findAll());
        return "/spteacher/searchByStudent";
    }

    @GetMapping("/spteacher/ascOrDesc")
    public String ascOrDesc(
            Model model,
            @RequestParam String sort
    ) {
        System.out.println(sort);
        switch (sort) {
            case "numAsc":
                model.addAttribute("studentAll",studentRepository.findByOrderByUsernameAsc());
                break;
            case "numDesc":
                model.addAttribute("studentAll",studentRepository.findByOrderByUsernameDesc());
                break;
            case "workAsc":
                model.addAttribute("studentAll",studentRepository.findByOrderByIndustryAsc());
                break;
            case "workDesc":
                model.addAttribute("studentAll",studentRepository.findByOrderByIndustryDesc());
                break;
            case "classAsc":
                model.addAttribute("studentAll",studentRepository.findByOrderByClassNameAsc());
                break;
            case "classDesc":
                model.addAttribute("studentAll",studentRepository.findByOrderByClassNameDesc());
                break;
            default:
                model.addAttribute("studentAll",studentRepository.findAll());
                break;
        }
        return "/spteacher/searchByStudent";
    }

    @PostMapping("/spteacher/studentDelete")
    public String studentDelete(
            Model model,
            @RequestParam String username
    ) {
        UpdateAssistance updateAssistance = new UpdateAssistance();
        SiteUser siteUser = userRepository.findByUsername(username);
        SiteUser siteUser1 = updateAssistance.deleteStudent(
                username,
                siteUser.getPassword(),
                siteUser.getName(),
                siteUser.getEmail()
                );

        userRepository.save(siteUser1);
        studentRepository.deleteById(username);
        return "redirect:/spteacher/searchByStudent";
    }

    @RequestMapping("/spteacher/studentDetail")
    public String studentDetail(
            Model model,
            @RequestParam String username
    ) {
        //reserveテーブル（説明会予約）を配列で0~*件取得
        //user(ユーザ情報)を一件取得
        //student(ユーザ情報)で一件取得
        //qualification(資格情報)を配列で0~*件取得
        model.addAttribute("reserve",reserveRepository.findByUsername(username));
        model.addAttribute("user",userRepository.findByUsername(username));
        model.addAttribute("studentHello",studentRepository.findByUsername(username));
        model.addAttribute("qualification", qualificationRepository.findByUsername(username));
        return "/spteacher/studentDetail";
    }

}
