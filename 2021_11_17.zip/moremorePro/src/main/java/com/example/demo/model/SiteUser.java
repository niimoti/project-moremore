package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@Setter
@Getter
@Entity
@Table(name = "users")
@NoArgsConstructor
@AllArgsConstructor
public class SiteUser {

    //ユーザ認証で使うname
    //メールアドレスの@より前、教師は先頭のgを抜いた文字列
    @Id
    @Column(name = "username")
    public String username;

    //ユーザ認証で使うpassword
    //4~10文字　半角英数字のみ
    @Column(name = "password")
    private String password;

    //例：田中太郎
    @Column(name = "name")
    private String name;

    @NotBlank
    @Email
    @Column(name = "email")
    private String email;

    @Column(name = "role")
    private String role;

    @Column(name = "teacher")
    private boolean teacher;

    @Column(name = "sp_teacher")
    private boolean spTeacher;

    @Column(name = "student")
    private boolean student;

    @Column(name = "expired_student")
    private boolean expiredStudent;
}

