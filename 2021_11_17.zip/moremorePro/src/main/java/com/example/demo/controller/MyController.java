package com.example.demo.controller;

import com.example.demo.java.Path;
import com.example.demo.model.SiteUser;
import com.example.demo.repository.UserRepository;
import com.example.demo.util.Role;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@RequiredArgsConstructor
@Controller
public class MyController {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    //---------------------ログイン画面・未ログイン時の画面

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    //---------------------ログインした時の遷移先画面
    @GetMapping("/")
    public String showList(
            Authentication loginUser,
            Model model
            ) {
        model.addAttribute("username", loginUser.getName()); //username
        model.addAttribute("role", loginUser.getAuthorities()); //role
        Path path = new Path();

        //各roleのメニュー画面に遷移
        return path.securityPath(String.valueOf(loginUser.getAuthorities())) + "/menu";
    }

    @GetMapping("/spTeacher/page")
    public String page() {
        return "spTMenu";
    }

    //-------------------ユーザ新規作成-----------------------

    @GetMapping("/register")
    public String register(@ModelAttribute("user") SiteUser user) {
        return "register";
    }

    @PostMapping("/register")
    public String process(@ModelAttribute("user") SiteUser user,
                          BindingResult result) {
        if (result.hasErrors()){
            return "register";
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));

        if (user.isSpTeacher()) {
            user.setRole(Role.SPTEACHER.name());
        } else if (user.isTeacher()) {
            user.setRole(Role.TEACHER.name());
        } else if (user.isStudent()) {
            user.setRole(Role.STUDENT.name());
        } else {
            user.setRole(Role.EXPIREDSTUDENT.name());
        }
        userRepository.save(user);

        return "redirect:/login?register";

    }

    //--------------------------------------------------------

}
