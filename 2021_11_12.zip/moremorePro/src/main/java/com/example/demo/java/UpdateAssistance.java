package com.example.demo.java;

import com.example.demo.model.InformationSessionModel;
import com.example.demo.repository.InformationSessionRepository;
import org.springframework.stereotype.Component;

import java.util.Optional;

//ただただSQLのupdateをアシストするためのクラス
//InformationSessionModel型に更新内容を入れて渡すだけ

public class UpdateAssistance {

    InformationSessionRepository informationSessionRepository;

    public InformationSessionModel updateISM(
            String id,
            String day,
            String place,
            String deadline,
            String kName,
            String industry,
            String contents,
            String URL,
            String explanation,
            String tempfile
            ) {
        ExString exString = new ExString();
        InformationSessionModel model = new InformationSessionModel();

        model.setId(exString.getLong(id));
        model.setDay(day);
        model.setPlace(place);
        model.setDeadline(deadline);
        model.setKName(kName);
        model.setIndustry(industry);
        model.setContents(contents);
        model.setURL(URL);
        model.setExplanation(explanation);
        model.setTempfile(tempfile);

        System.out.println(model.getId());
        System.out.println(model.getContents());
        System.out.println(model.getDay());
        System.out.println(model.getDeadline());
        System.out.println(model.getExplanation());
        System.out.println(model.getIndustry());
        System.out.println(model.getKName());
        System.out.println(model.getPlace());
        System.out.println(model.getURL());
        System.out.println(model.getTempfile());

        return model;

    }

}
