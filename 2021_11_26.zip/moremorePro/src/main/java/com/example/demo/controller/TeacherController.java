package com.example.demo.controller;

import com.example.demo.repository.QualificationRepository;
import com.example.demo.repository.ReserveRepository;
import com.example.demo.repository.StudentRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TeacherController {

    //この権限は見るだけ^～竿竹^～
    //生徒情報・生徒の詳しい情報とかね
    private final StudentRepository studentRepository;
    private final ReserveRepository reserveRepository;
    private final UserRepository userRepository;
    private final QualificationRepository qualificationRepository;

    public TeacherController(StudentRepository studentRepository, ReserveRepository reserveRepository, UserRepository userRepository, QualificationRepository qualificationRepository) {
        this.studentRepository = studentRepository;
        this.reserveRepository = reserveRepository;
        this.userRepository = userRepository;
        this.qualificationRepository = qualificationRepository;
    }

    //学生一覧表示
    @GetMapping("/teacher/searchByStudent")
    public String searchByStudentPrint(
            Model model
    ) {
        model.addAttribute("studentAll",studentRepository.findAll());
        return "/teacher/searchByStudent";
    }

    @GetMapping("/teacher/ascOrDesc")
    public String ascOrDescPrint(
            Model model,
            @RequestParam String sort
    ) {
        System.out.println(sort);
        switch (sort) {
            case "numAsc":
                model.addAttribute("studentAll",studentRepository.findByOrderByUsernameAsc());
                break;
            case "numDesc":
                model.addAttribute("studentAll",studentRepository.findByOrderByUsernameDesc());
                break;
            case "workAsc":
                model.addAttribute("studentAll",studentRepository.findByOrderByIndustryAsc());
                break;
            case "workDesc":
                model.addAttribute("studentAll",studentRepository.findByOrderByIndustryDesc());
                break;
            case "classAsc":
                model.addAttribute("studentAll",studentRepository.findByOrderByClassNameAsc());
                break;
            case "classDesc":
                model.addAttribute("studentAll",studentRepository.findByOrderByClassNameDesc());
                break;
            default:
                model.addAttribute("studentAll",studentRepository.findAll());
                break;
        }
        return "/teacher/searchByStudent";
    }

    @RequestMapping("/teacher/studentDetail")
    public String studentDetailPrint(
            Model model,
            @RequestParam String username
    ) {
        //reserveテーブル（説明会予約）を配列で0~*件取得
        //user(ユーザ情報)を一件取得
        //student(ユーザ情報)で一件取得
        //qualification(資格情報)を配列で0~*件取得
        model.addAttribute("reserve",reserveRepository.findByUsername(username));
        model.addAttribute("user",userRepository.findByUsername(username));
        model.addAttribute("studentHello",studentRepository.findByUsername(username));
        model.addAttribute("qualification", qualificationRepository.findByUsername(username));
        return "/teacher/studentDetail";
    }

}
