package com.example.demo.repository;

import com.example.demo.model.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BriefingSessionRepository extends JpaRepository<Schedule, Long> {

    @Query(value = "SELECT * FROM SCHEDULE WHERE USER_ID = ?1", nativeQuery = true)
    List<Schedule> customFindScheduledDateById(String id);

//    @Query(value = "SELECT scheduled_date FROM SCHEDULE WHERE USER_ID = ?1", nativeQuery = true)
//    List<Schedule> customFindScheduledDateById(String id);

}
