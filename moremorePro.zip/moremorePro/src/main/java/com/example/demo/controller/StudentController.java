package com.example.demo.controller;

import com.example.demo.java.Time;
import com.example.demo.model.Reserve;
import com.example.demo.repository.ExplanationRepository;
import com.example.demo.repository.ReserveRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class StudentController {

    //学生Controller
    private final ExplanationRepository explanationRepository;
    private final UserRepository userRepository;
    private final ReserveRepository reserveRepository;

    @Autowired
    public StudentController(
            ExplanationRepository explanationRepository,
            UserRepository userRepository,
            ReserveRepository reserveRepository) {
        this.explanationRepository = explanationRepository;
        this.userRepository = userRepository;
        this.reserveRepository = reserveRepository;
    }


    @GetMapping("")
    public String studentMenu() {
        return "";
    }

    @GetMapping("ReserveSample")
    public String ReserveSample(Model model) {
        model.addAttribute("list",explanationRepository.findAll());
        model.addAttribute("users", userRepository.findAll());
        return "student/ReserveSample";
    }

    @PostMapping("Reservation")
    public String Reservation(
            Model model,
            @RequestParam String comname,
            @RequestParam String stuname
    ) {
        Reserve reserve = new Reserve();
        Time time = new Time();
        String timeStr = time.NowTime();
        System.out.println(timeStr);
        reserve.setCompanyname(comname);
        reserve.setUsername(stuname);
        reserve.setDatetime(timeStr);

        System.out.println(reserve.getCompanyname() +
                reserve.getUsername() +
                reserve.getDatetime());

        reserveRepository.save(reserve);
        model.addAttribute("comname",comname);
        model.addAttribute("stuname",stuname);
        return "student/ReserveConfirm";
    }

    @GetMapping("Reservationlist")
    public String Reservationlist(
            Model model,
            @RequestParam(defaultValue = "181002") String stuname
    ) {
        model.addAttribute("users", userRepository.findAll());
        model.addAttribute("reservation",reserveRepository.findAll());
        model.addAttribute("stu", stuname);
        return "student/Reservationlist";
    }
}
