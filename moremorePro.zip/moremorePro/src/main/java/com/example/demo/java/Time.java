package com.example.demo.java;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Time {
    public String NowTime() {
        LocalDateTime nowDateTime = LocalDateTime.now();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        String nowtime = nowDateTime.format( format );
        return nowtime;
    }
}
